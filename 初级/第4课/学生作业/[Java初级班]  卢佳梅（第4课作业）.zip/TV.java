package lx1;

public class TV {
	public String brand;
	public String  add;
	public double size;
	public int prize;
	public  void show(){
		System.out.println("Ʒ��"+"brand");
		System.out.print("����"+"add");
		System.out.print("�ߴ�"+"size");
		System.out.print("�۸�"+"prize");
		}

}	
	

