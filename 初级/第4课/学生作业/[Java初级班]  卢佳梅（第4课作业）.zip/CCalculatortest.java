package lx1;

public class CCalculatortest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				CCalculator count1=new CCalculator();
				count1.a=1;
				count1.b=2;
				count1.c=2;{
					System.out.println(count1.add());
					System.out.println(count1.sub());
					System.out.println(count1.mul());
					System.out.println(count1.avg());
				}
	}

}
